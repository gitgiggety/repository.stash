import json


def parse(criterions):
    filter = {}

    for json_criterion in criterions:
        criterion = json.loads(json_criterion)

        filter[criterion['type']] = parse_criterion(criterion)

    return filter


def parse_criterion(criterion):
    filter = {}

    filter['modifier'] = criterion['modifier']

    if isinstance(criterion['value'], dict) and 'depth' in criterion['value']:
        filter['value'] = list(map(lambda v: v['id'], criterion['value']['items']))
        filter['depth'] = criterion['value']['depth']
    elif isinstance(criterion['value'], list):
        filter['value'] = list(map(lambda v: v['id'], criterion['value']))
    else:
        filter['value'] = criterion['value']

    return filter
